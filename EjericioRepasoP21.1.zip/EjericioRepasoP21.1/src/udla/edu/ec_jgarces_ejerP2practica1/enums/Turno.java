package udla.edu.ec_jgarces_ejerP2practica1.enums;

public enum Turno {
    MAÑANA, TARDE, NOCHE
}